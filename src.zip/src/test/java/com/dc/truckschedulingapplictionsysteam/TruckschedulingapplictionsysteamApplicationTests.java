package com.dc.truckschedulingapplictionsysteam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TruckschedulingapplictionsysteamApplicationTests {

	@Test
	void contextLoads() {
	}

}
